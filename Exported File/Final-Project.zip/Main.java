import java.io.*;

public class Main {
  public static void main(String[] args) {
    try {
      GUI gui = new GUI();

    } catch (IOException e) {e.printStackTrace();}

  }
}
